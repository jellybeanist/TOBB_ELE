//  XCode kullaniyorum.
//  Point.h
//  bil142lab3
//
//  Created by Burak Can  KARAKURT on 17.02.2021.
//  Copyright © 2021 Burak Can  KARAKURT. All rights reserved.
//
#ifndef Point_h
#define Point_h

#include <stdio.h>
#include "LineSegment.h"

class Point{
private:
    int x,y;
public:
    Point();
    Point(int xitem,int yitem);
    int getx();
    int gety();
    void setx(int item);
    void sety(int item);
};


#endif /* Point_h */
