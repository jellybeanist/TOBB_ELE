//  XCode kullaniyorum.
//  Point.cpp
//  bil142lab3
//
//  Created by Burak Can  KARAKURT on 17.02.2021.
//  Copyright © 2021 Burak Can  KARAKURT. All rights reserved.
//

#include "Point.h"
#include <iostream>
using namespace std;

Point::Point(){
    x=0;
    y=0;
}

Point::Point(int xitem,int yitem){
    x=xitem;
    y=yitem;
}

int Point::getx(){
    return x;
}

int Point::gety(){
    return y;
}

void Point::setx(int itemx){
    x=itemx;
}

void Point::sety(int itemy){
    y=itemy;
}
