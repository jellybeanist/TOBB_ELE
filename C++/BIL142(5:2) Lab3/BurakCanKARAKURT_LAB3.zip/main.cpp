//  XCode kullaniyorum.
//  main.cpp
//  bil142lab3
//
//  Created by Burak Can  KARAKURT on 17.02.2021.
//  Copyright © 2021 Burak Can  KARAKURT. All rights reserved.
//

#include <iostream>
#include "Point.h"
#include "LineSegment.h"

int main(){

return 0;
}
