//  XCode kullaniyorum.
//  LineSegment.h
//  bil142lab3
//
//  Created by Burak Can  KARAKURT on 17.02.2021.
//  Copyright © 2021 Burak Can  KARAKURT. All rights reserved.
//
#ifndef LineSegment_h
#define LineSegment_h

#include <stdio.h>
#include "Point.h"
class LineSegment{
private:
    Point first,second;
public:
    LineSegment();
    LineSegment(int firstx,int firsty,int secondx,int secondy);
    void setfirst(Point first);
    void setsecond(Point second);
    LineSegment operator+(LineSegment &rhs);
    void operator<<(LineSegment &rhs);
    
};


#endif /* LineSegment_h */
