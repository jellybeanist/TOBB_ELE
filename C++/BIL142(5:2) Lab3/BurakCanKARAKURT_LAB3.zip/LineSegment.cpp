//  XCode kullaniyorum.
//  LineSegment.cpp
//  bil142lab3
//
//  Created by Burak Can  KARAKURT on 17.02.2021.
//  Copyright © 2021 Burak Can  KARAKURT. All rights reserved.
//

#include "LineSegment.h"
#include <iostream>
using namespace std;

LineSegment::LineSegment(){
    first=Point();
    second=Point();
}

LineSegment::LineSegment(int firstx,int firsty,int secondx,int secondy){
    first.setx(firstx);
    first.sety(firsty);
    second.setx(secondx);
    second.sety(secondy);
}
void LineSegment::setfirst(Point item1){
    first=item1;
}


void LineSegment::setsecond(Point item2){
    second=item2;
}

LineSegment LineSegment::operator+(LineSegment &rhs){
    LineSegment result;
    result.first.setx(first.getx()+rhs.first.getx());
    result.first.sety(first.gety()+rhs.first.gety());
    result.second.setx(first.getx()+rhs.first.getx());
    result.second.sety(first.gety()+rhs.first.gety());
    return result;
}

void LineSegment::operator<<(LineSegment &rhs){
    (cout<<"("<<rhs.first.getx()<<","<<rhs.first.gety()<<")--("<<rhs.second.getx()<<"");
}

